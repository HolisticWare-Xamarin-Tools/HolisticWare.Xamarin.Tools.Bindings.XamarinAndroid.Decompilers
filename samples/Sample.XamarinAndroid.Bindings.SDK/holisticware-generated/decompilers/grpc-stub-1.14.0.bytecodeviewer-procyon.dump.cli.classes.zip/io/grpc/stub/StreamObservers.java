package io.grpc.stub;

import io.grpc.*;
import java.util.*;
import com.google.common.base.*;

@ExperimentalApi
public final class StreamObservers
{
    public static <V> void copyWithFlowControl(final Iterator<V> source, final CallStreamObserver<V> target) {
        Preconditions.checkNotNull(source, (Object)"source");
        Preconditions.checkNotNull(target, (Object)"target");
        final class FlowControllingOnReadyHandler implements Runnable
        {
            @Override
            public void run() {
                while (target.isReady() && source.hasNext()) {
                    target.onNext(source.next());
                }
                if (!source.hasNext()) {
                    target.onCompleted();
                }
            }
        }
        target.setOnReadyHandler(new FlowControllingOnReadyHandler());
    }
    
    public static <V> void copyWithFlowControl(final Iterable<V> source, final CallStreamObserver<V> target) {
        Preconditions.checkNotNull(source, (Object)"source");
        copyWithFlowControl(source.iterator(), target);
    }
}
