package io.grpc.stub;

import io.grpc.*;

private static final class UnaryStreamToFuture<RespT> extends ClientCall.Listener<RespT>
{
    private final GrpcFuture<RespT> responseFuture;
    private RespT value;
    
    UnaryStreamToFuture(final GrpcFuture<RespT> responseFuture) {
        this.responseFuture = responseFuture;
    }
    
    public void onHeaders(final Metadata headers) {
    }
    
    public void onMessage(final RespT value) {
        if (this.value != null) {
            throw Status.INTERNAL.withDescription("More than one value received for unary call").asRuntimeException();
        }
        this.value = value;
    }
    
    public void onClose(final Status status, final Metadata trailers) {
        if (status.isOk()) {
            if (this.value == null) {
                this.responseFuture.setException((Throwable)Status.INTERNAL.withDescription("No value received for unary call").asRuntimeException(trailers));
            }
            this.responseFuture.set(this.value);
        }
        else {
            this.responseFuture.setException((Throwable)status.asRuntimeException(trailers));
        }
    }
}
