package io.grpc.stub;

import com.google.common.base.*;
import io.grpc.*;

private static final class HeaderAttachingClientInterceptor implements ClientInterceptor
{
    private final Metadata extraHeaders;
    
    HeaderAttachingClientInterceptor(final Metadata extraHeaders) {
        this.extraHeaders = Preconditions.checkNotNull(extraHeaders, extraHeaders);
    }
    
    public <ReqT, RespT> ClientCall<ReqT, RespT> interceptCall(final MethodDescriptor<ReqT, RespT> method, final CallOptions callOptions, final Channel next) {
        return (ClientCall<ReqT, RespT>)new HeaderAttachingClientCall((io.grpc.ClientCall<Object, Object>)next.newCall((MethodDescriptor)method, callOptions));
    }
    
    private final class HeaderAttachingClientCall<ReqT, RespT> extends ForwardingClientCall.SimpleForwardingClientCall<ReqT, RespT>
    {
        HeaderAttachingClientCall(final ClientCall<ReqT, RespT> call) {
            super((ClientCall)call);
        }
        
        public void start(final ClientCall.Listener<RespT> responseListener, final Metadata headers) {
            headers.merge(HeaderAttachingClientInterceptor.this.extraHeaders);
            super.start((ClientCall.Listener)responseListener, headers);
        }
    }
}
