package io.grpc.stub;

import io.grpc.*;
import com.google.common.base.*;

private final class StreamingServerCallListener extends ServerCall.Listener<ReqT>
{
    private final StreamObserver<ReqT> requestObserver;
    private final ServerCallStreamObserverImpl<ReqT, RespT> responseObserver;
    private final ServerCall<ReqT, RespT> call;
    private boolean halfClosed;
    
    StreamingServerCallListener(final StreamObserver<ReqT> requestObserver, final ServerCallStreamObserverImpl<ReqT, RespT> responseObserver, final ServerCall<ReqT, RespT> call) {
        this.halfClosed = false;
        this.requestObserver = requestObserver;
        this.responseObserver = responseObserver;
        this.call = call;
    }
    
    public void onMessage(final ReqT request) {
        this.requestObserver.onNext(request);
        if (((ServerCallStreamObserverImpl<Object, Object>)this.responseObserver).autoFlowControlEnabled) {
            this.call.request(1);
        }
    }
    
    public void onHalfClose() {
        this.halfClosed = true;
        this.requestObserver.onCompleted();
    }
    
    public void onCancel() {
        this.responseObserver.cancelled = true;
        if (((ServerCallStreamObserverImpl<Object, Object>)this.responseObserver).onCancelHandler != null) {
            ((ServerCallStreamObserverImpl<Object, Object>)this.responseObserver).onCancelHandler.run();
        }
        if (!this.halfClosed) {
            this.requestObserver.onError((Throwable)Status.CANCELLED.withDescription("cancelled before receiving half close").asRuntimeException());
        }
    }
    
    public void onReady() {
        if (((ServerCallStreamObserverImpl<Object, Object>)this.responseObserver).onReadyHandler != null) {
            ((ServerCallStreamObserverImpl<Object, Object>)this.responseObserver).onReadyHandler.run();
        }
    }
}
