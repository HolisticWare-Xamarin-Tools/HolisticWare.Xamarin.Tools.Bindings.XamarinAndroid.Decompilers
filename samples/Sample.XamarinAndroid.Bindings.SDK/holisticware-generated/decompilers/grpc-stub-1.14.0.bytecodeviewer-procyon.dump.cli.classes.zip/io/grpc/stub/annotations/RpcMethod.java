package io.grpc.stub.annotations;

import java.lang.annotation.*;
import io.grpc.*;

@Retention(RetentionPolicy.CLASS)
@Target({ ElementType.METHOD })
public @interface RpcMethod {
    String fullMethodName();
    
    Class<?> requestType();
    
    Class<?> responseType();
    
    MethodDescriptor.MethodType methodType();
}
