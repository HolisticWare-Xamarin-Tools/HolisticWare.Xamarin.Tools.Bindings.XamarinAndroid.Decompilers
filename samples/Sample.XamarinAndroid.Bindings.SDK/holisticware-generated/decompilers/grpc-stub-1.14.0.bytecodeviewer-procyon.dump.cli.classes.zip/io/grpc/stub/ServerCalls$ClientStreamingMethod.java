package io.grpc.stub;

public interface ClientStreamingMethod<ReqT, RespT> extends StreamingRequestMethod<ReqT, RespT>
{
}
