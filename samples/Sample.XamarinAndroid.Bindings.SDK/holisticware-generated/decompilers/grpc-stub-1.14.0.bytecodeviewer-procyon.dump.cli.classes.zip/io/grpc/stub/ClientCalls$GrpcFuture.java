package io.grpc.stub;

import com.google.common.util.concurrent.*;
import io.grpc.*;
import javax.annotation.*;
import com.google.common.base.*;

private static final class GrpcFuture<RespT> extends AbstractFuture<RespT>
{
    private final ClientCall<?, RespT> call;
    
    GrpcFuture(final ClientCall<?, RespT> call) {
        this.call = call;
    }
    
    @Override
    protected void interruptTask() {
        this.call.cancel("GrpcFuture was cancelled", (Throwable)null);
    }
    
    @Override
    protected boolean set(@Nullable final RespT resp) {
        return super.set(resp);
    }
    
    @Override
    protected boolean setException(final Throwable throwable) {
        return super.setException(throwable);
    }
    
    protected String pendingToString() {
        return MoreObjects.toStringHelper((Object)this).add("clientCall", (Object)this.call).toString();
    }
}
