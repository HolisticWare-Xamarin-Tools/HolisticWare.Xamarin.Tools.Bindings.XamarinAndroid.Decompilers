package io.grpc.stub;

import com.google.errorprone.annotations.*;
import io.grpc.*;
import javax.annotation.*;

@DoNotMock
@ExperimentalApi("https://github.com/grpc/grpc-java/issues/1788")
public abstract class ClientCallStreamObserver<V> extends CallStreamObserver<V>
{
    public abstract void cancel(@Nullable final String p0, @Nullable final Throwable p1);
}
