package io.grpc.stub;

static class NoopStreamObserver<V> implements StreamObserver<V>
{
    @Override
    public void onNext(final V value) {
    }
    
    @Override
    public void onError(final Throwable t) {
    }
    
    @Override
    public void onCompleted() {
    }
}
