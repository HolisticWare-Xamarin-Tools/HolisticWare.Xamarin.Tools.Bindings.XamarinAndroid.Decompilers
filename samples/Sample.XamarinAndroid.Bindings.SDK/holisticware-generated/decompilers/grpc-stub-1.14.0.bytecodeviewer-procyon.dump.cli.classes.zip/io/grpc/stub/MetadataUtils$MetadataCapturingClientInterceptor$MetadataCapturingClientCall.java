package io.grpc.stub;

import io.grpc.*;

private final class MetadataCapturingClientCall<ReqT, RespT> extends ForwardingClientCall.SimpleForwardingClientCall<ReqT, RespT>
{
    MetadataCapturingClientCall(final ClientCall<ReqT, RespT> call) {
        super((ClientCall)call);
    }
    
    public void start(final ClientCall.Listener<RespT> responseListener, final Metadata headers) {
        MetadataCapturingClientInterceptor.this.headersCapture.set(null);
        MetadataCapturingClientInterceptor.this.trailersCapture.set(null);
        super.start((ClientCall.Listener)new MetadataCapturingClientCallListener(responseListener), headers);
    }
    
    private final class MetadataCapturingClientCallListener extends ForwardingClientCallListener.SimpleForwardingClientCallListener<RespT>
    {
        MetadataCapturingClientCallListener(final ClientCall.Listener<RespT> responseListener) {
            super((ClientCall.Listener)responseListener);
        }
        
        public void onHeaders(final Metadata headers) {
            MetadataCapturingClientInterceptor.this.headersCapture.set(headers);
            super.onHeaders(headers);
        }
        
        public void onClose(final Status status, final Metadata trailers) {
            MetadataCapturingClientInterceptor.this.trailersCapture.set(trailers);
            super.onClose(status, trailers);
        }
    }
}
