package io.grpc.stub;

import io.grpc.*;
import javax.annotation.*;

private static final class CallToStreamObserverAdapter<T> extends ClientCallStreamObserver<T>
{
    private boolean frozen;
    private final ClientCall<T, ?> call;
    private Runnable onReadyHandler;
    private boolean autoFlowControlEnabled;
    
    CallToStreamObserverAdapter(final ClientCall<T, ?> call) {
        this.autoFlowControlEnabled = true;
        this.call = call;
    }
    
    private void freeze() {
        this.frozen = true;
    }
    
    @Override
    public void onNext(final T value) {
        this.call.sendMessage((Object)value);
    }
    
    @Override
    public void onError(final Throwable t) {
        this.call.cancel("Cancelled by client with StreamObserver.onError()", t);
    }
    
    @Override
    public void onCompleted() {
        this.call.halfClose();
    }
    
    @Override
    public boolean isReady() {
        return this.call.isReady();
    }
    
    @Override
    public void setOnReadyHandler(final Runnable onReadyHandler) {
        if (this.frozen) {
            throw new IllegalStateException("Cannot alter onReadyHandler after call started");
        }
        this.onReadyHandler = onReadyHandler;
    }
    
    @Override
    public void disableAutoInboundFlowControl() {
        if (this.frozen) {
            throw new IllegalStateException("Cannot disable auto flow control call started");
        }
        this.autoFlowControlEnabled = false;
    }
    
    @Override
    public void request(final int count) {
        this.call.request(count);
    }
    
    @Override
    public void setMessageCompression(final boolean enable) {
        this.call.setMessageCompression(enable);
    }
    
    @Override
    public void cancel(@Nullable final String message, @Nullable final Throwable cause) {
        this.call.cancel(message, cause);
    }
}
