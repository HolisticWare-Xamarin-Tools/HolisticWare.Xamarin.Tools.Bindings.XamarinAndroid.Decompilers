package io.grpc.stub;

import com.google.common.base.*;
import io.grpc.*;

private static final class UnaryServerCallHandler<ReqT, RespT> implements ServerCallHandler<ReqT, RespT>
{
    private final UnaryRequestMethod<ReqT, RespT> method;
    
    UnaryServerCallHandler(final UnaryRequestMethod<ReqT, RespT> method) {
        this.method = method;
    }
    
    public ServerCall.Listener<ReqT> startCall(final ServerCall<ReqT, RespT> call, final Metadata headers) {
        Preconditions.checkArgument(call.getMethodDescriptor().getType().clientSendsOneMessage(), (Object)"asyncUnaryRequestCall is only for clientSendsOneMessage methods");
        final ServerCallStreamObserverImpl<ReqT, RespT> responseObserver = new ServerCallStreamObserverImpl<ReqT, RespT>(call);
        call.request(2);
        return new UnaryServerCallListener(responseObserver, call);
    }
    
    private final class UnaryServerCallListener extends ServerCall.Listener<ReqT>
    {
        private final ServerCall<ReqT, RespT> call;
        private final ServerCallStreamObserverImpl<ReqT, RespT> responseObserver;
        private boolean canInvoke;
        private ReqT request;
        
        UnaryServerCallListener(final ServerCallStreamObserverImpl<ReqT, RespT> responseObserver, final ServerCall<ReqT, RespT> call) {
            this.canInvoke = true;
            this.call = call;
            this.responseObserver = responseObserver;
        }
        
        public void onMessage(final ReqT request) {
            if (this.request != null) {
                this.call.close(Status.INTERNAL.withDescription("Too many requests"), new Metadata());
                this.canInvoke = false;
                return;
            }
            this.request = request;
        }
        
        public void onHalfClose() {
            if (!this.canInvoke) {
                return;
            }
            if (this.request == null) {
                this.call.close(Status.INTERNAL.withDescription("Half-closed without a request"), new Metadata());
                return;
            }
            UnaryServerCallHandler.this.method.invoke(this.request, this.responseObserver);
            ((ServerCallStreamObserverImpl<Object, Object>)this.responseObserver).freeze();
            if (this.call.isReady()) {
                this.onReady();
            }
        }
        
        public void onCancel() {
            this.responseObserver.cancelled = true;
            if (((ServerCallStreamObserverImpl<Object, Object>)this.responseObserver).onCancelHandler != null) {
                ((ServerCallStreamObserverImpl<Object, Object>)this.responseObserver).onCancelHandler.run();
            }
        }
        
        public void onReady() {
            if (((ServerCallStreamObserverImpl<Object, Object>)this.responseObserver).onReadyHandler != null) {
                ((ServerCallStreamObserverImpl<Object, Object>)this.responseObserver).onReadyHandler.run();
            }
        }
    }
}
