package io.grpc.stub;

public interface StreamObserver<V>
{
    void onNext(final V p0);
    
    void onError(final Throwable p0);
    
    void onCompleted();
}
