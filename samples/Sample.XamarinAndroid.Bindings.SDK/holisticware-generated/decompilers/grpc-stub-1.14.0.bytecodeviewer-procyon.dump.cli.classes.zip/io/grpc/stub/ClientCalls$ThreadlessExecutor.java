package io.grpc.stub;

import java.util.concurrent.*;
import java.util.logging.*;

private static final class ThreadlessExecutor implements Executor
{
    private static final Logger log;
    private final BlockingQueue<Runnable> queue;
    
    ThreadlessExecutor() {
        this.queue = new LinkedBlockingQueue<Runnable>();
    }
    
    public void waitAndDrain() throws InterruptedException {
        for (Runnable runnable = this.queue.take(); runnable != null; runnable = this.queue.poll()) {
            try {
                runnable.run();
            }
            catch (Throwable t) {
                ThreadlessExecutor.log.log(Level.WARNING, "Runnable threw exception", t);
            }
        }
    }
    
    @Override
    public void execute(final Runnable runnable) {
        this.queue.add(runnable);
    }
    
    static {
        log = Logger.getLogger(ThreadlessExecutor.class.getName());
    }
}
