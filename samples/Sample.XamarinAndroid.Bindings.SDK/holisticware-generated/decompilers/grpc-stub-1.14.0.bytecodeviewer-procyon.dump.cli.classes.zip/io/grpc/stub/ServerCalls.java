package io.grpc.stub;

import com.google.common.annotations.*;
import com.google.common.base.*;
import io.grpc.*;

public final class ServerCalls
{
    @VisibleForTesting
    static final String TOO_MANY_REQUESTS = "Too many requests";
    @VisibleForTesting
    static final String MISSING_REQUEST = "Half-closed without a request";
    
    public static <ReqT, RespT> ServerCallHandler<ReqT, RespT> asyncUnaryCall(final UnaryMethod<ReqT, RespT> method) {
        return asyncUnaryRequestCall(method);
    }
    
    public static <ReqT, RespT> ServerCallHandler<ReqT, RespT> asyncServerStreamingCall(final ServerStreamingMethod<ReqT, RespT> method) {
        return asyncUnaryRequestCall(method);
    }
    
    public static <ReqT, RespT> ServerCallHandler<ReqT, RespT> asyncClientStreamingCall(final ClientStreamingMethod<ReqT, RespT> method) {
        return asyncStreamingRequestCall(method);
    }
    
    public static <ReqT, RespT> ServerCallHandler<ReqT, RespT> asyncBidiStreamingCall(final BidiStreamingMethod<ReqT, RespT> method) {
        return asyncStreamingRequestCall(method);
    }
    
    private static <ReqT, RespT> ServerCallHandler<ReqT, RespT> asyncUnaryRequestCall(final UnaryRequestMethod<ReqT, RespT> method) {
        return (ServerCallHandler<ReqT, RespT>)new UnaryServerCallHandler((UnaryRequestMethod<Object, Object>)method);
    }
    
    private static <ReqT, RespT> ServerCallHandler<ReqT, RespT> asyncStreamingRequestCall(final StreamingRequestMethod<ReqT, RespT> method) {
        return (ServerCallHandler<ReqT, RespT>)new StreamingServerCallHandler((StreamingRequestMethod<Object, Object>)method);
    }
    
    public static void asyncUnimplementedUnaryCall(final MethodDescriptor<?, ?> methodDescriptor, final StreamObserver<?> responseObserver) {
        Preconditions.checkNotNull(methodDescriptor, (Object)"methodDescriptor");
        Preconditions.checkNotNull(responseObserver, (Object)"responseObserver");
        responseObserver.onError((Throwable)Status.UNIMPLEMENTED.withDescription(String.format("Method %s is unimplemented", methodDescriptor.getFullMethodName())).asRuntimeException());
    }
    
    public static <T> StreamObserver<T> asyncUnimplementedStreamingCall(final MethodDescriptor<?, ?> methodDescriptor, final StreamObserver<?> responseObserver) {
        asyncUnimplementedUnaryCall(methodDescriptor, responseObserver);
        return new NoopStreamObserver<T>();
    }
    
    private static final class UnaryServerCallHandler<ReqT, RespT> implements ServerCallHandler<ReqT, RespT>
    {
        private final UnaryRequestMethod<ReqT, RespT> method;
        
        UnaryServerCallHandler(final UnaryRequestMethod<ReqT, RespT> method) {
            this.method = method;
        }
        
        public ServerCall.Listener<ReqT> startCall(final ServerCall<ReqT, RespT> call, final Metadata headers) {
            Preconditions.checkArgument(call.getMethodDescriptor().getType().clientSendsOneMessage(), (Object)"asyncUnaryRequestCall is only for clientSendsOneMessage methods");
            final ServerCallStreamObserverImpl<ReqT, RespT> responseObserver = new ServerCallStreamObserverImpl<ReqT, RespT>(call);
            call.request(2);
            return new UnaryServerCallListener(responseObserver, call);
        }
        
        private final class UnaryServerCallListener extends ServerCall.Listener<ReqT>
        {
            private final ServerCall<ReqT, RespT> call;
            private final ServerCallStreamObserverImpl<ReqT, RespT> responseObserver;
            private boolean canInvoke;
            private ReqT request;
            
            UnaryServerCallListener(final ServerCallStreamObserverImpl<ReqT, RespT> responseObserver, final ServerCall<ReqT, RespT> call) {
                this.canInvoke = true;
                this.call = call;
                this.responseObserver = responseObserver;
            }
            
            public void onMessage(final ReqT request) {
                if (this.request != null) {
                    this.call.close(Status.INTERNAL.withDescription("Too many requests"), new Metadata());
                    this.canInvoke = false;
                    return;
                }
                this.request = request;
            }
            
            public void onHalfClose() {
                if (!this.canInvoke) {
                    return;
                }
                if (this.request == null) {
                    this.call.close(Status.INTERNAL.withDescription("Half-closed without a request"), new Metadata());
                    return;
                }
                UnaryServerCallHandler.this.method.invoke(this.request, this.responseObserver);
                ((ServerCallStreamObserverImpl<Object, Object>)this.responseObserver).freeze();
                if (this.call.isReady()) {
                    this.onReady();
                }
            }
            
            public void onCancel() {
                this.responseObserver.cancelled = true;
                if (((ServerCallStreamObserverImpl<Object, Object>)this.responseObserver).onCancelHandler != null) {
                    ((ServerCallStreamObserverImpl<Object, Object>)this.responseObserver).onCancelHandler.run();
                }
            }
            
            public void onReady() {
                if (((ServerCallStreamObserverImpl<Object, Object>)this.responseObserver).onReadyHandler != null) {
                    ((ServerCallStreamObserverImpl<Object, Object>)this.responseObserver).onReadyHandler.run();
                }
            }
        }
    }
    
    private static final class StreamingServerCallHandler<ReqT, RespT> implements ServerCallHandler<ReqT, RespT>
    {
        private final StreamingRequestMethod<ReqT, RespT> method;
        
        StreamingServerCallHandler(final StreamingRequestMethod<ReqT, RespT> method) {
            this.method = method;
        }
        
        public ServerCall.Listener<ReqT> startCall(final ServerCall<ReqT, RespT> call, final Metadata headers) {
            final ServerCallStreamObserverImpl<ReqT, RespT> responseObserver = new ServerCallStreamObserverImpl<ReqT, RespT>(call);
            final StreamObserver<ReqT> requestObserver = this.method.invoke((StreamObserver<RespT>)responseObserver);
            ((ServerCallStreamObserverImpl<Object, Object>)responseObserver).freeze();
            if (((ServerCallStreamObserverImpl<Object, Object>)responseObserver).autoFlowControlEnabled) {
                call.request(1);
            }
            return new StreamingServerCallListener(requestObserver, responseObserver, call);
        }
        
        private final class StreamingServerCallListener extends ServerCall.Listener<ReqT>
        {
            private final StreamObserver<ReqT> requestObserver;
            private final ServerCallStreamObserverImpl<ReqT, RespT> responseObserver;
            private final ServerCall<ReqT, RespT> call;
            private boolean halfClosed;
            
            StreamingServerCallListener(final StreamObserver<ReqT> requestObserver, final ServerCallStreamObserverImpl<ReqT, RespT> responseObserver, final ServerCall<ReqT, RespT> call) {
                this.halfClosed = false;
                this.requestObserver = requestObserver;
                this.responseObserver = responseObserver;
                this.call = call;
            }
            
            public void onMessage(final ReqT request) {
                this.requestObserver.onNext(request);
                if (((ServerCallStreamObserverImpl<Object, Object>)this.responseObserver).autoFlowControlEnabled) {
                    this.call.request(1);
                }
            }
            
            public void onHalfClose() {
                this.halfClosed = true;
                this.requestObserver.onCompleted();
            }
            
            public void onCancel() {
                this.responseObserver.cancelled = true;
                if (((ServerCallStreamObserverImpl<Object, Object>)this.responseObserver).onCancelHandler != null) {
                    ((ServerCallStreamObserverImpl<Object, Object>)this.responseObserver).onCancelHandler.run();
                }
                if (!this.halfClosed) {
                    this.requestObserver.onError((Throwable)Status.CANCELLED.withDescription("cancelled before receiving half close").asRuntimeException());
                }
            }
            
            public void onReady() {
                if (((ServerCallStreamObserverImpl<Object, Object>)this.responseObserver).onReadyHandler != null) {
                    ((ServerCallStreamObserverImpl<Object, Object>)this.responseObserver).onReadyHandler.run();
                }
            }
        }
    }
    
    private static final class ServerCallStreamObserverImpl<ReqT, RespT> extends ServerCallStreamObserver<RespT>
    {
        final ServerCall<ReqT, RespT> call;
        volatile boolean cancelled;
        private boolean frozen;
        private boolean autoFlowControlEnabled;
        private boolean sentHeaders;
        private Runnable onReadyHandler;
        private Runnable onCancelHandler;
        
        ServerCallStreamObserverImpl(final ServerCall<ReqT, RespT> call) {
            this.autoFlowControlEnabled = true;
            this.call = call;
        }
        
        private void freeze() {
            this.frozen = true;
        }
        
        @Override
        public void setMessageCompression(final boolean enable) {
            this.call.setMessageCompression(enable);
        }
        
        @Override
        public void setCompression(final String compression) {
            this.call.setCompression(compression);
        }
        
        @Override
        public void onNext(final RespT response) {
            if (this.cancelled) {
                throw Status.CANCELLED.withDescription("call already cancelled").asRuntimeException();
            }
            if (!this.sentHeaders) {
                this.call.sendHeaders(new Metadata());
                this.sentHeaders = true;
            }
            this.call.sendMessage((Object)response);
        }
        
        @Override
        public void onError(final Throwable t) {
            Metadata metadata = Status.trailersFromThrowable(t);
            if (metadata == null) {
                metadata = new Metadata();
            }
            this.call.close(Status.fromThrowable(t), metadata);
        }
        
        @Override
        public void onCompleted() {
            if (this.cancelled) {
                throw Status.CANCELLED.withDescription("call already cancelled").asRuntimeException();
            }
            this.call.close(Status.OK, new Metadata());
        }
        
        @Override
        public boolean isReady() {
            return this.call.isReady();
        }
        
        @Override
        public void setOnReadyHandler(final Runnable r) {
            Preconditions.checkState(!this.frozen, "Cannot alter onReadyHandler after initialization");
            this.onReadyHandler = r;
        }
        
        @Override
        public boolean isCancelled() {
            return this.call.isCancelled();
        }
        
        @Override
        public void setOnCancelHandler(final Runnable onCancelHandler) {
            Preconditions.checkState(!this.frozen, "Cannot alter onCancelHandler after initialization");
            this.onCancelHandler = onCancelHandler;
        }
        
        @Override
        public void disableAutoInboundFlowControl() {
            Preconditions.checkState(!this.frozen, "Cannot disable auto flow control after initialization");
            this.autoFlowControlEnabled = false;
        }
        
        @Override
        public void request(final int count) {
            this.call.request(count);
        }
    }
    
    static class NoopStreamObserver<V> implements StreamObserver<V>
    {
        @Override
        public void onNext(final V value) {
        }
        
        @Override
        public void onError(final Throwable t) {
        }
        
        @Override
        public void onCompleted() {
        }
    }
    
    private interface StreamingRequestMethod<ReqT, RespT>
    {
        StreamObserver<ReqT> invoke(final StreamObserver<RespT> p0);
    }
    
    private interface UnaryRequestMethod<ReqT, RespT>
    {
        void invoke(final ReqT p0, final StreamObserver<RespT> p1);
    }
    
    public interface BidiStreamingMethod<ReqT, RespT> extends StreamingRequestMethod<ReqT, RespT>
    {
    }
    
    public interface ClientStreamingMethod<ReqT, RespT> extends StreamingRequestMethod<ReqT, RespT>
    {
    }
    
    public interface ServerStreamingMethod<ReqT, RespT> extends UnaryRequestMethod<ReqT, RespT>
    {
    }
    
    public interface UnaryMethod<ReqT, RespT> extends UnaryRequestMethod<ReqT, RespT>
    {
    }
}
