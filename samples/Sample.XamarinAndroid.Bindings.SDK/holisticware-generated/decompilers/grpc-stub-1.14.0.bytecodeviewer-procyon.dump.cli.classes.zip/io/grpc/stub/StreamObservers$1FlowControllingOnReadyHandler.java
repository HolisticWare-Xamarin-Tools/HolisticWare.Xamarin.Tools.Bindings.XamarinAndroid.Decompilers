package io.grpc.stub;

import java.util.*;

final class FlowControllingOnReadyHandler implements Runnable
{
    final /* synthetic */ CallStreamObserver val$target;
    final /* synthetic */ Iterator val$source;
    
    FlowControllingOnReadyHandler(final CallStreamObserver val$target, final Iterator val$source) {
        this.val$target = val$target;
        this.val$source = val$source;
    }
    
    @Override
    public void run() {
        while (this.val$target.isReady() && this.val$source.hasNext()) {
            this.val$target.onNext(this.val$source.next());
        }
        if (!this.val$source.hasNext()) {
            this.val$target.onCompleted();
        }
    }
}
