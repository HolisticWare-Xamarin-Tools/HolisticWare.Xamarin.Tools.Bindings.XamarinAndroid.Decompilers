package io.grpc.stub;

import io.grpc.*;
import com.google.common.base.*;

private static final class StreamingServerCallHandler<ReqT, RespT> implements ServerCallHandler<ReqT, RespT>
{
    private final StreamingRequestMethod<ReqT, RespT> method;
    
    StreamingServerCallHandler(final StreamingRequestMethod<ReqT, RespT> method) {
        this.method = method;
    }
    
    public ServerCall.Listener<ReqT> startCall(final ServerCall<ReqT, RespT> call, final Metadata headers) {
        final ServerCallStreamObserverImpl<ReqT, RespT> responseObserver = new ServerCallStreamObserverImpl<ReqT, RespT>(call);
        final StreamObserver<ReqT> requestObserver = this.method.invoke((StreamObserver<RespT>)responseObserver);
        ((ServerCallStreamObserverImpl<Object, Object>)responseObserver).freeze();
        if (((ServerCallStreamObserverImpl<Object, Object>)responseObserver).autoFlowControlEnabled) {
            call.request(1);
        }
        return new StreamingServerCallListener(requestObserver, responseObserver, call);
    }
    
    private final class StreamingServerCallListener extends ServerCall.Listener<ReqT>
    {
        private final StreamObserver<ReqT> requestObserver;
        private final ServerCallStreamObserverImpl<ReqT, RespT> responseObserver;
        private final ServerCall<ReqT, RespT> call;
        private boolean halfClosed;
        
        StreamingServerCallListener(final StreamObserver<ReqT> requestObserver, final ServerCallStreamObserverImpl<ReqT, RespT> responseObserver, final ServerCall<ReqT, RespT> call) {
            this.halfClosed = false;
            this.requestObserver = requestObserver;
            this.responseObserver = responseObserver;
            this.call = call;
        }
        
        public void onMessage(final ReqT request) {
            this.requestObserver.onNext(request);
            if (((ServerCallStreamObserverImpl<Object, Object>)this.responseObserver).autoFlowControlEnabled) {
                this.call.request(1);
            }
        }
        
        public void onHalfClose() {
            this.halfClosed = true;
            this.requestObserver.onCompleted();
        }
        
        public void onCancel() {
            this.responseObserver.cancelled = true;
            if (((ServerCallStreamObserverImpl<Object, Object>)this.responseObserver).onCancelHandler != null) {
                ((ServerCallStreamObserverImpl<Object, Object>)this.responseObserver).onCancelHandler.run();
            }
            if (!this.halfClosed) {
                this.requestObserver.onError((Throwable)Status.CANCELLED.withDescription("cancelled before receiving half close").asRuntimeException());
            }
        }
        
        public void onReady() {
            if (((ServerCallStreamObserverImpl<Object, Object>)this.responseObserver).onReadyHandler != null) {
                ((ServerCallStreamObserverImpl<Object, Object>)this.responseObserver).onReadyHandler.run();
            }
        }
    }
}
