package io.grpc.stub;

public interface ServerStreamingMethod<ReqT, RespT> extends UnaryRequestMethod<ReqT, RespT>
{
}
