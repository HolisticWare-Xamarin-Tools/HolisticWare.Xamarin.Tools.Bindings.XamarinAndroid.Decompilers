package io.grpc.stub;

import java.util.logging.*;
import io.grpc.*;
import javax.annotation.*;
import com.google.common.util.concurrent.*;
import com.google.common.base.*;
import java.util.*;
import java.util.concurrent.*;

public final class ClientCalls
{
    private static final Logger logger;
    
    public static <ReqT, RespT> void asyncUnaryCall(final ClientCall<ReqT, RespT> call, final ReqT param, final StreamObserver<RespT> observer) {
        asyncUnaryRequestCall(call, param, observer, false);
    }
    
    public static <ReqT, RespT> void asyncServerStreamingCall(final ClientCall<ReqT, RespT> call, final ReqT param, final StreamObserver<RespT> responseObserver) {
        asyncUnaryRequestCall(call, param, responseObserver, true);
    }
    
    public static <ReqT, RespT> StreamObserver<ReqT> asyncClientStreamingCall(final ClientCall<ReqT, RespT> call, final StreamObserver<RespT> responseObserver) {
        return asyncStreamingRequestCall(call, responseObserver, false);
    }
    
    public static <ReqT, RespT> StreamObserver<ReqT> asyncBidiStreamingCall(final ClientCall<ReqT, RespT> call, final StreamObserver<RespT> responseObserver) {
        return asyncStreamingRequestCall(call, responseObserver, true);
    }
    
    public static <ReqT, RespT> RespT blockingUnaryCall(final ClientCall<ReqT, RespT> call, final ReqT param) {
        try {
            return getUnchecked(futureUnaryCall(call, param));
        }
        catch (RuntimeException e) {
            throw cancelThrow(call, e);
        }
        catch (Error e2) {
            throw cancelThrow(call, e2);
        }
    }
    
    public static <ReqT, RespT> RespT blockingUnaryCall(final Channel channel, final MethodDescriptor<ReqT, RespT> method, final CallOptions callOptions, final ReqT param) {
        final ThreadlessExecutor executor = new ThreadlessExecutor();
        final ClientCall<ReqT, RespT> call = (ClientCall<ReqT, RespT>)channel.newCall((MethodDescriptor)method, callOptions.withExecutor((Executor)executor));
        try {
            final ListenableFuture<RespT> responseFuture = futureUnaryCall(call, param);
            while (!responseFuture.isDone()) {
                try {
                    executor.waitAndDrain();
                    continue;
                }
                catch (InterruptedException e) {
                    Thread.currentThread().interrupt();
                    throw Status.CANCELLED.withDescription("Call was interrupted").withCause((Throwable)e).asRuntimeException();
                }
                break;
            }
            return getUnchecked(responseFuture);
        }
        catch (RuntimeException e2) {
            throw cancelThrow(call, e2);
        }
        catch (Error e3) {
            throw cancelThrow(call, e3);
        }
    }
    
    public static <ReqT, RespT> Iterator<RespT> blockingServerStreamingCall(final ClientCall<ReqT, RespT> call, final ReqT param) {
        final BlockingResponseStream<RespT> result = new BlockingResponseStream<RespT>(call);
        asyncUnaryRequestCall(call, param, result.listener(), true);
        return result;
    }
    
    public static <ReqT, RespT> Iterator<RespT> blockingServerStreamingCall(final Channel channel, final MethodDescriptor<ReqT, RespT> method, final CallOptions callOptions, final ReqT param) {
        final ThreadlessExecutor executor = new ThreadlessExecutor();
        final ClientCall<ReqT, RespT> call = (ClientCall<ReqT, RespT>)channel.newCall((MethodDescriptor)method, callOptions.withExecutor((Executor)executor));
        final BlockingResponseStream<RespT> result = new BlockingResponseStream<RespT>(call, executor);
        asyncUnaryRequestCall(call, param, result.listener(), true);
        return result;
    }
    
    public static <ReqT, RespT> ListenableFuture<RespT> futureUnaryCall(final ClientCall<ReqT, RespT> call, final ReqT param) {
        final GrpcFuture<RespT> responseFuture = new GrpcFuture<RespT>(call);
        asyncUnaryRequestCall(call, param, new UnaryStreamToFuture<RespT>(responseFuture), false);
        return responseFuture;
    }
    
    private static <V> V getUnchecked(final Future<V> future) {
        try {
            return future.get();
        }
        catch (InterruptedException e) {
            Thread.currentThread().interrupt();
            throw Status.CANCELLED.withDescription("Call was interrupted").withCause((Throwable)e).asRuntimeException();
        }
        catch (ExecutionException e2) {
            throw toStatusRuntimeException(e2.getCause());
        }
    }
    
    private static StatusRuntimeException toStatusRuntimeException(final Throwable t) {
        for (Throwable cause = Preconditions.checkNotNull(t, (Object)"t"); cause != null; cause = cause.getCause()) {
            if (cause instanceof StatusException) {
                final StatusException se = (StatusException)cause;
                return new StatusRuntimeException(se.getStatus(), se.getTrailers());
            }
            if (cause instanceof StatusRuntimeException) {
                final StatusRuntimeException se2 = (StatusRuntimeException)cause;
                return new StatusRuntimeException(se2.getStatus(), se2.getTrailers());
            }
        }
        return Status.UNKNOWN.withDescription("unexpected exception").withCause(t).asRuntimeException();
    }
    
    private static RuntimeException cancelThrow(final ClientCall<?, ?> call, final Throwable t) {
        try {
            call.cancel((String)null, t);
        }
        catch (Throwable e) {
            assert e instanceof RuntimeException || e instanceof Error;
            ClientCalls.logger.log(Level.SEVERE, "RuntimeException encountered while closing call", e);
        }
        if (t instanceof RuntimeException) {
            throw (RuntimeException)t;
        }
        if (t instanceof Error) {
            throw (Error)t;
        }
        throw new AssertionError((Object)t);
    }
    
    private static <ReqT, RespT> void asyncUnaryRequestCall(final ClientCall<ReqT, RespT> call, final ReqT param, final StreamObserver<RespT> responseObserver, final boolean streamingResponse) {
        asyncUnaryRequestCall(call, param, (ClientCall.Listener<RespT>)new StreamObserverToCallListenerAdapter((StreamObserver<Object>)responseObserver, new CallToStreamObserverAdapter<Object>((io.grpc.ClientCall<Object, ?>)call), streamingResponse), streamingResponse);
    }
    
    private static <ReqT, RespT> void asyncUnaryRequestCall(final ClientCall<ReqT, RespT> call, final ReqT param, final ClientCall.Listener<RespT> responseListener, final boolean streamingResponse) {
        startCall(call, responseListener, streamingResponse);
        try {
            call.sendMessage((Object)param);
            call.halfClose();
        }
        catch (RuntimeException e) {
            throw cancelThrow(call, e);
        }
        catch (Error e2) {
            throw cancelThrow(call, e2);
        }
    }
    
    private static <ReqT, RespT> StreamObserver<ReqT> asyncStreamingRequestCall(final ClientCall<ReqT, RespT> call, final StreamObserver<RespT> responseObserver, final boolean streamingResponse) {
        final CallToStreamObserverAdapter<ReqT> adapter = new CallToStreamObserverAdapter<ReqT>(call);
        startCall(call, (ClientCall.Listener<RespT>)new StreamObserverToCallListenerAdapter((StreamObserver<Object>)responseObserver, (CallToStreamObserverAdapter<Object>)adapter, streamingResponse), streamingResponse);
        return adapter;
    }
    
    private static <ReqT, RespT> void startCall(final ClientCall<ReqT, RespT> call, final ClientCall.Listener<RespT> responseListener, final boolean streamingResponse) {
        call.start((ClientCall.Listener)responseListener, new Metadata());
        if (streamingResponse) {
            call.request(1);
        }
        else {
            call.request(2);
        }
    }
    
    static {
        logger = Logger.getLogger(ClientCalls.class.getName());
    }
    
    private static final class CallToStreamObserverAdapter<T> extends ClientCallStreamObserver<T>
    {
        private boolean frozen;
        private final ClientCall<T, ?> call;
        private Runnable onReadyHandler;
        private boolean autoFlowControlEnabled;
        
        CallToStreamObserverAdapter(final ClientCall<T, ?> call) {
            this.autoFlowControlEnabled = true;
            this.call = call;
        }
        
        private void freeze() {
            this.frozen = true;
        }
        
        @Override
        public void onNext(final T value) {
            this.call.sendMessage((Object)value);
        }
        
        @Override
        public void onError(final Throwable t) {
            this.call.cancel("Cancelled by client with StreamObserver.onError()", t);
        }
        
        @Override
        public void onCompleted() {
            this.call.halfClose();
        }
        
        @Override
        public boolean isReady() {
            return this.call.isReady();
        }
        
        @Override
        public void setOnReadyHandler(final Runnable onReadyHandler) {
            if (this.frozen) {
                throw new IllegalStateException("Cannot alter onReadyHandler after call started");
            }
            this.onReadyHandler = onReadyHandler;
        }
        
        @Override
        public void disableAutoInboundFlowControl() {
            if (this.frozen) {
                throw new IllegalStateException("Cannot disable auto flow control call started");
            }
            this.autoFlowControlEnabled = false;
        }
        
        @Override
        public void request(final int count) {
            this.call.request(count);
        }
        
        @Override
        public void setMessageCompression(final boolean enable) {
            this.call.setMessageCompression(enable);
        }
        
        @Override
        public void cancel(@Nullable final String message, @Nullable final Throwable cause) {
            this.call.cancel(message, cause);
        }
    }
    
    private static final class StreamObserverToCallListenerAdapter<ReqT, RespT> extends ClientCall.Listener<RespT>
    {
        private final StreamObserver<RespT> observer;
        private final CallToStreamObserverAdapter<ReqT> adapter;
        private final boolean streamingResponse;
        private boolean firstResponseReceived;
        
        StreamObserverToCallListenerAdapter(final StreamObserver<RespT> observer, final CallToStreamObserverAdapter<ReqT> adapter, final boolean streamingResponse) {
            this.observer = observer;
            this.streamingResponse = streamingResponse;
            this.adapter = adapter;
            if (observer instanceof ClientResponseObserver) {
                final ClientResponseObserver<ReqT, RespT> clientResponseObserver = (ClientResponseObserver<ReqT, RespT>)(ClientResponseObserver)observer;
                clientResponseObserver.beforeStart(adapter);
            }
            ((CallToStreamObserverAdapter<Object>)adapter).freeze();
        }
        
        public void onHeaders(final Metadata headers) {
        }
        
        public void onMessage(final RespT message) {
            if (this.firstResponseReceived && !this.streamingResponse) {
                throw Status.INTERNAL.withDescription("More than one responses received for unary or client-streaming call").asRuntimeException();
            }
            this.firstResponseReceived = true;
            this.observer.onNext(message);
            if (this.streamingResponse && ((CallToStreamObserverAdapter<Object>)this.adapter).autoFlowControlEnabled) {
                this.adapter.request(1);
            }
        }
        
        public void onClose(final Status status, final Metadata trailers) {
            if (status.isOk()) {
                this.observer.onCompleted();
            }
            else {
                this.observer.onError((Throwable)status.asRuntimeException(trailers));
            }
        }
        
        public void onReady() {
            if (((CallToStreamObserverAdapter<Object>)this.adapter).onReadyHandler != null) {
                ((CallToStreamObserverAdapter<Object>)this.adapter).onReadyHandler.run();
            }
        }
    }
    
    private static final class UnaryStreamToFuture<RespT> extends ClientCall.Listener<RespT>
    {
        private final GrpcFuture<RespT> responseFuture;
        private RespT value;
        
        UnaryStreamToFuture(final GrpcFuture<RespT> responseFuture) {
            this.responseFuture = responseFuture;
        }
        
        public void onHeaders(final Metadata headers) {
        }
        
        public void onMessage(final RespT value) {
            if (this.value != null) {
                throw Status.INTERNAL.withDescription("More than one value received for unary call").asRuntimeException();
            }
            this.value = value;
        }
        
        public void onClose(final Status status, final Metadata trailers) {
            if (status.isOk()) {
                if (this.value == null) {
                    this.responseFuture.setException((Throwable)Status.INTERNAL.withDescription("No value received for unary call").asRuntimeException(trailers));
                }
                this.responseFuture.set(this.value);
            }
            else {
                this.responseFuture.setException((Throwable)status.asRuntimeException(trailers));
            }
        }
    }
    
    private static final class GrpcFuture<RespT> extends AbstractFuture<RespT>
    {
        private final ClientCall<?, RespT> call;
        
        GrpcFuture(final ClientCall<?, RespT> call) {
            this.call = call;
        }
        
        @Override
        protected void interruptTask() {
            this.call.cancel("GrpcFuture was cancelled", (Throwable)null);
        }
        
        @Override
        protected boolean set(@Nullable final RespT resp) {
            return super.set(resp);
        }
        
        @Override
        protected boolean setException(final Throwable throwable) {
            return super.setException(throwable);
        }
        
        protected String pendingToString() {
            return MoreObjects.toStringHelper((Object)this).add("clientCall", (Object)this.call).toString();
        }
    }
    
    private static final class BlockingResponseStream<T> implements Iterator<T>
    {
        private final BlockingQueue<Object> buffer;
        private final ClientCall.Listener<T> listener;
        private final ClientCall<?, T> call;
        private final ThreadlessExecutor threadless;
        private Object last;
        
        BlockingResponseStream(final ClientCall<?, T> call) {
            this(call, null);
        }
        
        BlockingResponseStream(final ClientCall<?, T> call, final ThreadlessExecutor threadless) {
            this.buffer = new ArrayBlockingQueue<Object>(2);
            this.listener = new QueuingListener();
            this.call = call;
            this.threadless = threadless;
        }
        
        ClientCall.Listener<T> listener() {
            return this.listener;
        }
        
        private Object waitForNext() throws InterruptedException {
            if (this.threadless == null) {
                return this.buffer.take();
            }
            Object next;
            for (next = this.buffer.poll(); next == null; next = this.buffer.poll()) {
                this.threadless.waitAndDrain();
            }
            return next;
        }
        
        @Override
        public boolean hasNext() {
            if (this.last == null) {
                try {
                    this.last = this.waitForNext();
                }
                catch (InterruptedException ie) {
                    Thread.currentThread().interrupt();
                    throw Status.CANCELLED.withDescription("interrupted").withCause((Throwable)ie).asRuntimeException();
                }
            }
            if (this.last instanceof StatusRuntimeException) {
                final StatusRuntimeException e = (StatusRuntimeException)this.last;
                throw e.getStatus().asRuntimeException(e.getTrailers());
            }
            return this.last != this;
        }
        
        @Override
        public T next() {
            if (!this.hasNext()) {
                throw new NoSuchElementException();
            }
            try {
                this.call.request(1);
                final T tmp = (T)this.last;
                return tmp;
            }
            finally {
                this.last = null;
            }
        }
        
        @Override
        public void remove() {
            throw new UnsupportedOperationException();
        }
        
        private final class QueuingListener extends ClientCall.Listener<T>
        {
            private boolean done;
            
            QueuingListener() {
                this.done = false;
            }
            
            public void onHeaders(final Metadata headers) {
            }
            
            public void onMessage(final T value) {
                Preconditions.checkState(!this.done, "ClientCall already closed");
                BlockingResponseStream.this.buffer.add(value);
            }
            
            public void onClose(final Status status, final Metadata trailers) {
                Preconditions.checkState(!this.done, "ClientCall already closed");
                if (status.isOk()) {
                    BlockingResponseStream.this.buffer.add(BlockingResponseStream.this);
                }
                else {
                    BlockingResponseStream.this.buffer.add(status.asRuntimeException(trailers));
                }
                this.done = true;
            }
        }
    }
    
    private static final class ThreadlessExecutor implements Executor
    {
        private static final Logger log;
        private final BlockingQueue<Runnable> queue;
        
        ThreadlessExecutor() {
            this.queue = new LinkedBlockingQueue<Runnable>();
        }
        
        public void waitAndDrain() throws InterruptedException {
            for (Runnable runnable = this.queue.take(); runnable != null; runnable = this.queue.poll()) {
                try {
                    runnable.run();
                }
                catch (Throwable t) {
                    ThreadlessExecutor.log.log(Level.WARNING, "Runnable threw exception", t);
                }
            }
        }
        
        @Override
        public void execute(final Runnable runnable) {
            this.queue.add(runnable);
        }
        
        static {
            log = Logger.getLogger(ThreadlessExecutor.class.getName());
        }
    }
}
