package io.grpc.stub;

import io.grpc.*;

private final class MetadataCapturingClientCallListener extends ForwardingClientCallListener.SimpleForwardingClientCallListener<RespT>
{
    MetadataCapturingClientCallListener(final ClientCall.Listener<RespT> responseListener) {
        super((ClientCall.Listener)responseListener);
    }
    
    public void onHeaders(final Metadata headers) {
        MetadataCapturingClientCall.this.this$0.headersCapture.set(headers);
        super.onHeaders(headers);
    }
    
    public void onClose(final Status status, final Metadata trailers) {
        MetadataCapturingClientCall.this.this$0.trailersCapture.set(trailers);
        super.onClose(status, trailers);
    }
}
