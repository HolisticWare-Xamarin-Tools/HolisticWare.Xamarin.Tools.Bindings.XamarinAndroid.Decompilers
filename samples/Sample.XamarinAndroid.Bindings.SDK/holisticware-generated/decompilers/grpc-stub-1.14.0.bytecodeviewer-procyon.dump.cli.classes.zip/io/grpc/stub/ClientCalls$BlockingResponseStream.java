package io.grpc.stub;

import java.util.concurrent.*;
import java.util.*;
import io.grpc.*;
import com.google.common.base.*;

private static final class BlockingResponseStream<T> implements Iterator<T>
{
    private final BlockingQueue<Object> buffer;
    private final ClientCall.Listener<T> listener;
    private final ClientCall<?, T> call;
    private final ThreadlessExecutor threadless;
    private Object last;
    
    BlockingResponseStream(final ClientCall<?, T> call) {
        this(call, null);
    }
    
    BlockingResponseStream(final ClientCall<?, T> call, final ThreadlessExecutor threadless) {
        this.buffer = new ArrayBlockingQueue<Object>(2);
        this.listener = new QueuingListener();
        this.call = call;
        this.threadless = threadless;
    }
    
    ClientCall.Listener<T> listener() {
        return this.listener;
    }
    
    private Object waitForNext() throws InterruptedException {
        if (this.threadless == null) {
            return this.buffer.take();
        }
        Object next;
        for (next = this.buffer.poll(); next == null; next = this.buffer.poll()) {
            this.threadless.waitAndDrain();
        }
        return next;
    }
    
    @Override
    public boolean hasNext() {
        if (this.last == null) {
            try {
                this.last = this.waitForNext();
            }
            catch (InterruptedException ie) {
                Thread.currentThread().interrupt();
                throw Status.CANCELLED.withDescription("interrupted").withCause((Throwable)ie).asRuntimeException();
            }
        }
        if (this.last instanceof StatusRuntimeException) {
            final StatusRuntimeException e = (StatusRuntimeException)this.last;
            throw e.getStatus().asRuntimeException(e.getTrailers());
        }
        return this.last != this;
    }
    
    @Override
    public T next() {
        if (!this.hasNext()) {
            throw new NoSuchElementException();
        }
        try {
            this.call.request(1);
            final T tmp = (T)this.last;
            return tmp;
        }
        finally {
            this.last = null;
        }
    }
    
    @Override
    public void remove() {
        throw new UnsupportedOperationException();
    }
    
    private final class QueuingListener extends ClientCall.Listener<T>
    {
        private boolean done;
        
        QueuingListener() {
            this.done = false;
        }
        
        public void onHeaders(final Metadata headers) {
        }
        
        public void onMessage(final T value) {
            Preconditions.checkState(!this.done, "ClientCall already closed");
            BlockingResponseStream.this.buffer.add(value);
        }
        
        public void onClose(final Status status, final Metadata trailers) {
            Preconditions.checkState(!this.done, "ClientCall already closed");
            if (status.isOk()) {
                BlockingResponseStream.this.buffer.add(BlockingResponseStream.this);
            }
            else {
                BlockingResponseStream.this.buffer.add(status.asRuntimeException(trailers));
            }
            this.done = true;
        }
    }
}
