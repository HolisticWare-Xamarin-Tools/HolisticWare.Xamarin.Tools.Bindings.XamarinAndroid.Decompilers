package io.grpc.stub;

public interface UnaryMethod<ReqT, RespT> extends UnaryRequestMethod<ReqT, RespT>
{
}
