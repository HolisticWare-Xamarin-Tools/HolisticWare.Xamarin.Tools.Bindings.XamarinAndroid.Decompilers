package io.grpc.stub;

import com.google.errorprone.annotations.*;
import io.grpc.*;

@DoNotMock
@ExperimentalApi("https://github.com/grpc/grpc-java/issues/1788")
public abstract class CallStreamObserver<V> implements StreamObserver<V>
{
    public abstract boolean isReady();
    
    public abstract void setOnReadyHandler(final Runnable p0);
    
    public abstract void disableAutoInboundFlowControl();
    
    public abstract void request(final int p0);
    
    public abstract void setMessageCompression(final boolean p0);
}
