package io.grpc.stub;

import com.google.errorprone.annotations.*;
import io.grpc.*;

@DoNotMock
@ExperimentalApi("https://github.com/grpc/grpc-java/issues/1788")
public abstract class ServerCallStreamObserver<V> extends CallStreamObserver<V>
{
    public abstract boolean isCancelled();
    
    public abstract void setOnCancelHandler(final Runnable p0);
    
    public abstract void setCompression(final String p0);
}
