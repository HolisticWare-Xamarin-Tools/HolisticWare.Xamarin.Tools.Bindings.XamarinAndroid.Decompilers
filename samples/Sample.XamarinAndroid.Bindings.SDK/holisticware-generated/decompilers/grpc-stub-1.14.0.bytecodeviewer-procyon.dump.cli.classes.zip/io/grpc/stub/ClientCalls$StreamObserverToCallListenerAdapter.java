package io.grpc.stub;

import io.grpc.*;
import javax.annotation.*;

private static final class StreamObserverToCallListenerAdapter<ReqT, RespT> extends ClientCall.Listener<RespT>
{
    private final StreamObserver<RespT> observer;
    private final CallToStreamObserverAdapter<ReqT> adapter;
    private final boolean streamingResponse;
    private boolean firstResponseReceived;
    
    StreamObserverToCallListenerAdapter(final StreamObserver<RespT> observer, final CallToStreamObserverAdapter<ReqT> adapter, final boolean streamingResponse) {
        this.observer = observer;
        this.streamingResponse = streamingResponse;
        this.adapter = adapter;
        if (observer instanceof ClientResponseObserver) {
            final ClientResponseObserver<ReqT, RespT> clientResponseObserver = (ClientResponseObserver<ReqT, RespT>)(ClientResponseObserver)observer;
            clientResponseObserver.beforeStart(adapter);
        }
        ((CallToStreamObserverAdapter<Object>)adapter).freeze();
    }
    
    public void onHeaders(final Metadata headers) {
    }
    
    public void onMessage(final RespT message) {
        if (this.firstResponseReceived && !this.streamingResponse) {
            throw Status.INTERNAL.withDescription("More than one responses received for unary or client-streaming call").asRuntimeException();
        }
        this.firstResponseReceived = true;
        this.observer.onNext(message);
        if (this.streamingResponse && ((CallToStreamObserverAdapter<Object>)this.adapter).autoFlowControlEnabled) {
            this.adapter.request(1);
        }
    }
    
    public void onClose(final Status status, final Metadata trailers) {
        if (status.isOk()) {
            this.observer.onCompleted();
        }
        else {
            this.observer.onError((Throwable)status.asRuntimeException(trailers));
        }
    }
    
    public void onReady() {
        if (((CallToStreamObserverAdapter<Object>)this.adapter).onReadyHandler != null) {
            ((CallToStreamObserverAdapter<Object>)this.adapter).onReadyHandler.run();
        }
    }
}
