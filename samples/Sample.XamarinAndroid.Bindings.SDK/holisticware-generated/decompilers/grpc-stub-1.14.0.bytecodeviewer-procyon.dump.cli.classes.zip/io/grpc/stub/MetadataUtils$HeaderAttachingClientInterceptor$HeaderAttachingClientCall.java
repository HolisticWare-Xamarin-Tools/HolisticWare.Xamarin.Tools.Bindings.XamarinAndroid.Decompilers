package io.grpc.stub;

import io.grpc.*;

private final class HeaderAttachingClientCall<ReqT, RespT> extends ForwardingClientCall.SimpleForwardingClientCall<ReqT, RespT>
{
    HeaderAttachingClientCall(final ClientCall<ReqT, RespT> call) {
        super((ClientCall)call);
    }
    
    public void start(final ClientCall.Listener<RespT> responseListener, final Metadata headers) {
        headers.merge(HeaderAttachingClientInterceptor.access$000(HeaderAttachingClientInterceptor.this));
        super.start((ClientCall.Listener)responseListener, headers);
    }
}
