package io.grpc.stub;

import io.grpc.*;
import com.google.common.base.*;

private static final class ServerCallStreamObserverImpl<ReqT, RespT> extends ServerCallStreamObserver<RespT>
{
    final ServerCall<ReqT, RespT> call;
    volatile boolean cancelled;
    private boolean frozen;
    private boolean autoFlowControlEnabled;
    private boolean sentHeaders;
    private Runnable onReadyHandler;
    private Runnable onCancelHandler;
    
    ServerCallStreamObserverImpl(final ServerCall<ReqT, RespT> call) {
        this.autoFlowControlEnabled = true;
        this.call = call;
    }
    
    private void freeze() {
        this.frozen = true;
    }
    
    @Override
    public void setMessageCompression(final boolean enable) {
        this.call.setMessageCompression(enable);
    }
    
    @Override
    public void setCompression(final String compression) {
        this.call.setCompression(compression);
    }
    
    @Override
    public void onNext(final RespT response) {
        if (this.cancelled) {
            throw Status.CANCELLED.withDescription("call already cancelled").asRuntimeException();
        }
        if (!this.sentHeaders) {
            this.call.sendHeaders(new Metadata());
            this.sentHeaders = true;
        }
        this.call.sendMessage((Object)response);
    }
    
    @Override
    public void onError(final Throwable t) {
        Metadata metadata = Status.trailersFromThrowable(t);
        if (metadata == null) {
            metadata = new Metadata();
        }
        this.call.close(Status.fromThrowable(t), metadata);
    }
    
    @Override
    public void onCompleted() {
        if (this.cancelled) {
            throw Status.CANCELLED.withDescription("call already cancelled").asRuntimeException();
        }
        this.call.close(Status.OK, new Metadata());
    }
    
    @Override
    public boolean isReady() {
        return this.call.isReady();
    }
    
    @Override
    public void setOnReadyHandler(final Runnable r) {
        Preconditions.checkState(!this.frozen, "Cannot alter onReadyHandler after initialization");
        this.onReadyHandler = r;
    }
    
    @Override
    public boolean isCancelled() {
        return this.call.isCancelled();
    }
    
    @Override
    public void setOnCancelHandler(final Runnable onCancelHandler) {
        Preconditions.checkState(!this.frozen, "Cannot alter onCancelHandler after initialization");
        this.onCancelHandler = onCancelHandler;
    }
    
    @Override
    public void disableAutoInboundFlowControl() {
        Preconditions.checkState(!this.frozen, "Cannot disable auto flow control after initialization");
        this.autoFlowControlEnabled = false;
    }
    
    @Override
    public void request(final int count) {
        this.call.request(count);
    }
}
