package io.grpc.stub;

import io.grpc.*;

@ExperimentalApi
public interface ClientResponseObserver<ReqT, RespT> extends StreamObserver<RespT>
{
    void beforeStart(final ClientCallStreamObserver<ReqT> p0);
}
