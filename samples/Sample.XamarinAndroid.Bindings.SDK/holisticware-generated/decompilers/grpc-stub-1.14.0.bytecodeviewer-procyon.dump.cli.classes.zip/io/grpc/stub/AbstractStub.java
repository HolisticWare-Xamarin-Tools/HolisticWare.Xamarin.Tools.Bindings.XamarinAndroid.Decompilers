package io.grpc.stub;

import com.google.errorprone.annotations.*;
import javax.annotation.concurrent.*;
import com.google.common.base.*;
import javax.annotation.*;
import java.util.concurrent.*;
import io.grpc.*;

@DoNotMock
@CheckReturnValue
@ThreadSafe
public abstract class AbstractStub<S extends AbstractStub<S>>
{
    private final Channel channel;
    private final CallOptions callOptions;
    
    protected AbstractStub(final Channel channel) {
        this(channel, CallOptions.DEFAULT);
    }
    
    protected AbstractStub(final Channel channel, final CallOptions callOptions) {
        this.channel = Preconditions.checkNotNull(channel, (Object)"channel");
        this.callOptions = Preconditions.checkNotNull(callOptions, (Object)"callOptions");
    }
    
    public final Channel getChannel() {
        return this.channel;
    }
    
    public final CallOptions getCallOptions() {
        return this.callOptions;
    }
    
    protected abstract S build(final Channel p0, final CallOptions p1);
    
    public final S withDeadline(@Nullable final Deadline deadline) {
        return this.build(this.channel, this.callOptions.withDeadline(deadline));
    }
    
    public final S withDeadlineAfter(final long duration, final TimeUnit unit) {
        return this.build(this.channel, this.callOptions.withDeadlineAfter(duration, unit));
    }
    
    @ExperimentalApi("https://github.com/grpc/grpc-java/issues/3605")
    public final S withExecutor(final Executor executor) {
        return this.build(this.channel, this.callOptions.withExecutor(executor));
    }
    
    @ExperimentalApi("https://github.com/grpc/grpc-java/issues/1704")
    public final S withCompression(final String compressorName) {
        return this.build(this.channel, this.callOptions.withCompression(compressorName));
    }
    
    @Deprecated
    public final S withChannel(final Channel newChannel) {
        return this.build(newChannel, this.callOptions);
    }
    
    @ExperimentalApi("https://github.com/grpc/grpc-java/issues/1869")
    public final <T> S withOption(final CallOptions.Key<T> key, final T value) {
        return this.build(this.channel, this.callOptions.withOption((CallOptions.Key)key, (Object)value));
    }
    
    public final S withInterceptors(final ClientInterceptor... interceptors) {
        return this.build(ClientInterceptors.intercept(this.channel, interceptors), this.callOptions);
    }
    
    public final S withCallCredentials(final CallCredentials credentials) {
        return this.build(this.channel, this.callOptions.withCallCredentials(credentials));
    }
    
    public final S withWaitForReady() {
        return this.build(this.channel, this.callOptions.withWaitForReady());
    }
    
    @ExperimentalApi("https://github.com/grpc/grpc-java/issues/2563")
    public final S withMaxInboundMessageSize(final int maxSize) {
        return this.build(this.channel, this.callOptions.withMaxInboundMessageSize(maxSize));
    }
    
    @ExperimentalApi("https://github.com/grpc/grpc-java/issues/2563")
    public final S withMaxOutboundMessageSize(final int maxSize) {
        return this.build(this.channel, this.callOptions.withMaxOutboundMessageSize(maxSize));
    }
}
