package io.grpc.stub;

private interface StreamingRequestMethod<ReqT, RespT>
{
    StreamObserver<ReqT> invoke(final StreamObserver<RespT> p0);
}
