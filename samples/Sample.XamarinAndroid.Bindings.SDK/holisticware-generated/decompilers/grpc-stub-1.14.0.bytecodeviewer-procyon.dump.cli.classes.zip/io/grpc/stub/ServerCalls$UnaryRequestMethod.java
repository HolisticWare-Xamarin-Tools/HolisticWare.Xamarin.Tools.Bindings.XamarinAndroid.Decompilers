package io.grpc.stub;

private interface UnaryRequestMethod<ReqT, RespT>
{
    void invoke(final ReqT p0, final StreamObserver<RespT> p1);
}
