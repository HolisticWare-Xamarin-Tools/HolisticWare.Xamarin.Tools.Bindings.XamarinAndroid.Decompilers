package io.grpc.stub;

public interface BidiStreamingMethod<ReqT, RespT> extends StreamingRequestMethod<ReqT, RespT>
{
}
