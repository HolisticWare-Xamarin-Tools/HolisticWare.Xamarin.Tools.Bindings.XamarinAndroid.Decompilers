package io.grpc.stub;

import java.util.concurrent.atomic.*;
import com.google.common.base.*;
import io.grpc.*;

public final class MetadataUtils
{
    @ExperimentalApi("https://github.com/grpc/grpc-java/issues/1789")
    public static <T extends AbstractStub<T>> T attachHeaders(final T stub, final Metadata extraHeaders) {
        return stub.withInterceptors(newAttachHeadersInterceptor(extraHeaders));
    }
    
    public static ClientInterceptor newAttachHeadersInterceptor(final Metadata extraHeaders) {
        return (ClientInterceptor)new HeaderAttachingClientInterceptor(extraHeaders);
    }
    
    @ExperimentalApi("https://github.com/grpc/grpc-java/issues/1789")
    public static <T extends AbstractStub<T>> T captureMetadata(final T stub, final AtomicReference<Metadata> headersCapture, final AtomicReference<Metadata> trailersCapture) {
        return stub.withInterceptors(newCaptureMetadataInterceptor(headersCapture, trailersCapture));
    }
    
    public static ClientInterceptor newCaptureMetadataInterceptor(final AtomicReference<Metadata> headersCapture, final AtomicReference<Metadata> trailersCapture) {
        return (ClientInterceptor)new MetadataCapturingClientInterceptor(headersCapture, trailersCapture);
    }
    
    private static final class HeaderAttachingClientInterceptor implements ClientInterceptor
    {
        private final Metadata extraHeaders;
        
        HeaderAttachingClientInterceptor(final Metadata extraHeaders) {
            this.extraHeaders = Preconditions.checkNotNull(extraHeaders, extraHeaders);
        }
        
        public <ReqT, RespT> ClientCall<ReqT, RespT> interceptCall(final MethodDescriptor<ReqT, RespT> method, final CallOptions callOptions, final Channel next) {
            return (ClientCall<ReqT, RespT>)new HeaderAttachingClientCall((io.grpc.ClientCall<Object, Object>)next.newCall((MethodDescriptor)method, callOptions));
        }
        
        private final class HeaderAttachingClientCall<ReqT, RespT> extends ForwardingClientCall.SimpleForwardingClientCall<ReqT, RespT>
        {
            HeaderAttachingClientCall(final ClientCall<ReqT, RespT> call) {
                super((ClientCall)call);
            }
            
            public void start(final ClientCall.Listener<RespT> responseListener, final Metadata headers) {
                headers.merge(HeaderAttachingClientInterceptor.this.extraHeaders);
                super.start((ClientCall.Listener)responseListener, headers);
            }
        }
    }
    
    private static final class MetadataCapturingClientInterceptor implements ClientInterceptor
    {
        final AtomicReference<Metadata> headersCapture;
        final AtomicReference<Metadata> trailersCapture;
        
        MetadataCapturingClientInterceptor(final AtomicReference<Metadata> headersCapture, final AtomicReference<Metadata> trailersCapture) {
            this.headersCapture = Preconditions.checkNotNull(headersCapture, (Object)"headersCapture");
            this.trailersCapture = Preconditions.checkNotNull(trailersCapture, (Object)"trailersCapture");
        }
        
        public <ReqT, RespT> ClientCall<ReqT, RespT> interceptCall(final MethodDescriptor<ReqT, RespT> method, final CallOptions callOptions, final Channel next) {
            return (ClientCall<ReqT, RespT>)new MetadataCapturingClientCall((io.grpc.ClientCall<Object, Object>)next.newCall((MethodDescriptor)method, callOptions));
        }
        
        private final class MetadataCapturingClientCall<ReqT, RespT> extends ForwardingClientCall.SimpleForwardingClientCall<ReqT, RespT>
        {
            MetadataCapturingClientCall(final ClientCall<ReqT, RespT> call) {
                super((ClientCall)call);
            }
            
            public void start(final ClientCall.Listener<RespT> responseListener, final Metadata headers) {
                MetadataCapturingClientInterceptor.this.headersCapture.set(null);
                MetadataCapturingClientInterceptor.this.trailersCapture.set(null);
                super.start((ClientCall.Listener)new MetadataCapturingClientCallListener(responseListener), headers);
            }
            
            private final class MetadataCapturingClientCallListener extends ForwardingClientCallListener.SimpleForwardingClientCallListener<RespT>
            {
                MetadataCapturingClientCallListener(final ClientCall.Listener<RespT> responseListener) {
                    super((ClientCall.Listener)responseListener);
                }
                
                public void onHeaders(final Metadata headers) {
                    MetadataCapturingClientInterceptor.this.headersCapture.set(headers);
                    super.onHeaders(headers);
                }
                
                public void onClose(final Status status, final Metadata trailers) {
                    MetadataCapturingClientInterceptor.this.trailersCapture.set(trailers);
                    super.onClose(status, trailers);
                }
            }
        }
    }
}
