package io.grpc.stub;

import com.google.common.base.*;
import io.grpc.*;

private final class QueuingListener extends ClientCall.Listener<T>
{
    private boolean done;
    
    QueuingListener() {
        this.done = false;
    }
    
    public void onHeaders(final Metadata headers) {
    }
    
    public void onMessage(final T value) {
        Preconditions.checkState(!this.done, "ClientCall already closed");
        BlockingResponseStream.access$300(BlockingResponseStream.this).add(value);
    }
    
    public void onClose(final Status status, final Metadata trailers) {
        Preconditions.checkState(!this.done, "ClientCall already closed");
        if (status.isOk()) {
            BlockingResponseStream.access$300(BlockingResponseStream.this).add(BlockingResponseStream.this);
        }
        else {
            BlockingResponseStream.access$300(BlockingResponseStream.this).add(status.asRuntimeException(trailers));
        }
        this.done = true;
    }
}
