/*
 * Decompiled with CFR 0_125.
 * 
 * Could not load the following classes:
 *  io.grpc.ExperimentalApi
 */
package io.grpc.stub;

import com.google.common.base.Preconditions;
import io.grpc.ExperimentalApi;
import io.grpc.stub.CallStreamObserver;
import java.util.Iterator;

@ExperimentalApi
public final class StreamObservers {
    public static <V> void copyWithFlowControl(Iterator<V> source, CallStreamObserver<V> target) {
        final class FlowControllingOnReadyHandler
        implements Runnable {
            final /* synthetic */ Iterator val$source;

            FlowControllingOnReadyHandler() {
                this.val$source = var2_2;
            }

            @Override
            public void run() {
                while (val$target.isReady() && this.val$source.hasNext()) {
                    val$target.onNext(this.val$source.next());
                }
                if (this.val$source.hasNext()) return;
                val$target.onCompleted();
            }
        }
        Preconditions.checkNotNull(source, "source");
        Preconditions.checkNotNull(target, "target");
        target.setOnReadyHandler(new FlowControllingOnReadyHandler(target, source));
    }

    public static <V> void copyWithFlowControl(Iterable<V> source, CallStreamObserver<V> target) {
        Preconditions.checkNotNull(source, "source");
        StreamObservers.copyWithFlowControl(source.iterator(), target);
    }

}

