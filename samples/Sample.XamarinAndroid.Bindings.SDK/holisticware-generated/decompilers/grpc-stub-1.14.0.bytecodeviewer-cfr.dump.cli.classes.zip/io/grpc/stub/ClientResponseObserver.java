/*
 * Decompiled with CFR 0_125.
 * 
 * Could not load the following classes:
 *  io.grpc.ExperimentalApi
 */
package io.grpc.stub;

import io.grpc.ExperimentalApi;
import io.grpc.stub.ClientCallStreamObserver;
import io.grpc.stub.StreamObserver;

@ExperimentalApi
public interface ClientResponseObserver<ReqT, RespT>
extends StreamObserver<RespT> {
    public void beforeStart(ClientCallStreamObserver<ReqT> var1);
}

